### Wordpress Team Slider
A Team Members carousel plugin for Wordpress.
